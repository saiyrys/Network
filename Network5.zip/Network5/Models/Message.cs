﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task_1.Models
{
    public class Message
    {
        public int Id { get; set; }
        public string? Text { get; set; }
        public DateTime DateMessage { get; set; }
        public bool IsReceived { get; set; }

        public bool NewMessage { get; set; } = true;
        public bool IsRead { get; set; }
        public int? ToUserId { get; set; }
        
        public virtual User? ToUser { get; set; }
    }
}
